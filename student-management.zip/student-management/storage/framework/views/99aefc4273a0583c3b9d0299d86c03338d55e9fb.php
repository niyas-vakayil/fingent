<?php $__env->startPush('css'); ?>
    <title>Student-Management</title>
     <!-- calender -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/bootstrap-datepicker3.standalone.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/bootstrap-datepicker3.min.css')); ?>">

    <!-- end calender -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" as="style"> 
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/pages/add-teacher.css')); ?>">


    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css" as="style"> 
    <link rel="stylesheet" href="assets/css/pages/live-classes.css">
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>

                <div class="main-dashboard-wrap col py-3">
                <div class="row">
                        <div class="col-md-4">
                            <!-- <a class="ttl-12 text-c-text mb-2 d-inline-block" href="dashboard.php"><span class="icon-chevron-left text-icon-gray ttl-9 top-1"></span> Back</a> -->
                            <h4 class="ttl-18 my-2">Students</h4>
                        </div>
                        <div class="col-md-8 text-right">
                            <ul class="list-unstyled list-inline mb-0">                                
                                <li class="list-inline-item align-top">
                                    <div class="dropdown show">
                                        <a class="btn btn-outline-gray ttl-14 mh-40" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <span class="icon-filter mr-2"></span>
                                            Filter
                                        </a>

                                        <div class="dropdown-menu dropdown-menu-right filter-menu" aria-labelledby="dropdownMenuLink">

                                            <div class="px-3 pt-3 pb-1">    
                                                <div class="iilt-group1 input-group w-100 flex-sm-row-reverse search-user-id-code-input mw-100">
                                                        <input type="text" class="form-control" placeholder="Search filter">
                                                        <div class="input-group-append cursor-pointer">
                                                            <div class="input-group-text"><span class="icon-search"></span></div>
                                                        </div>
                                                    </div>
                                            </div>


                                            <hr>


                                            <hr>

                                           






                                        </div>
                                    </div>
                                </li>
                                <li class="list-inline-item align-top">
                                    <a href="<?php echo e(route('students.create')); ?>" class="btn btn-primary"><span class="icon-plus mr-1 ttl-10"></span> Add Student</a>
                                </li>                                
                            </ul>
                        </div>
                    </div>

                    <!--  -->
                    <div class="row dashboard-row mt-2">
                        
                        
                        
                        <!--  -->
                        <div class="col-full">
                            <div class="col-content-wrap col-content-border p-0 h-100">





                            <div class="tab-iilt">
                                
                                <div class="tab-content table-no-outline-border" id="myTabContent">                                    

                                    <div class="tab-pane fade show active" id="modulesVideos" role="tabpanel" aria-labelledby="modulesVideos-tab">
                                        <div class="col-content-body my-class-body">
                                    
                                            <div class="custom-data-table-wrap hide-paginate">
                                                <table id="example" class="display custom-data-table live-data-table modules-page-table" style="width:100%">
                                                    <thead>
                                                        <tr class="text-bluelight-color">
                                                            <th class="no-sorting">ID</th>
                                                            <th class="no-sorting">Name</th>
                                                            <th class="no-sorting">Age</th>
                                                            <th class="no-sorting">Gender</th>
                                                            <th class="no-sorting">Reporting Teacher</th>    
                                                                                                                       
                                                            <th class="no-sorting" style="width: 120px"></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php if(isset($students)): ?>
                                                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            
                                                            <td class="pl-3"><?php echo e($student->id); ?></td>
                                                            <td class="pl-3"><?php echo e($student->name); ?></td>
                                                            <td class="pl-3"><?php echo e($student->age); ?></td>
                                                            <td class="pl-3"><?php echo e($student->gender); ?></td>
                                                            <td class="pl-3"><?php echo e($student->reporting_teacher); ?></td>
                                                            <td class="text-right">
                                                                <div class="dropdown">
                                                                    <button class="btn btn-link p-0 text-c-gray" type="button" id="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                        <span class="icon-options"></span>
                                                                    </button>
                                                                    <div class="dropdown-menu" aria-labelledby="">
                                                                        <a class="dropdown-item ttl-13 py-2" href="<?php echo e(route('students.edit',$student->id)); ?>">Edit</a>                                                                    
                                                                        <a class="dropdown-item ttl-13 py-2" href="<?php echo e(route('students.destroy',$student->id)); ?>">Delete</a>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                            
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>

                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                    </tbody>
                                                </table>
                                            </div>
                                        
                                        </div>
                                    </div>

                                    
                                </div>

                                <!--  -->





                                    
                                </div>



                                 


                            </div>

                            </div>
                        </div>

                    </div>
                    <!--  -->
                </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <!-- select2 -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
    <!-- date picker -->
    <script type="text/javascript" src="assets/js/bootstrap-datepicker.min.js"></script>
    <!-- main js -->
    <script type="text/javascript" src="assets/js/main.js"></script>


    <script>
        $("[data-link]").on("click",function(){
            window.location.href = $(this).attr("data-link")
        });

        // Dropdown Menu
        $('.dropdown-menu').click(function(e) {
            e.stopPropagation();
        });
        
        // Uncheck Checkbox
        function uncheckAll() {
        document.querySelectorAll('input[type="checkbox"]')
            .forEach(el => el.checked = false);
        }
        document.querySelector('#btnClear').addEventListener('click', uncheckAll)

        // Button Click Close Dropdown
        $("#btnDone").click(function(){
            $(this).parents('.dropdown').find('#dropdownMenuLink').dropdown('toggle')
        });
    </script>




	<script>

	$(document).ready(function () {
		AddStudent.init();
		
	});



	</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/arjun_p_s/student-management/resources/views/admin/student-list.blade.php ENDPATH**/ ?>