<div class="left-menu-inner">
<ul class="left-menu-list">
    <li>
        <a id="H-link" href="<?php echo e(route('students.index')); ?>">
            <span class="icon-Home"></span>Student
        </a>
    </li>
    <li>
        <a id="registration-link" href="<?php echo e(route('marks.index')); ?>">
            <span class="icon-Home"></span>Marks
        </a>
    </li>
 
   
  
   
</ul>
</div><?php /**PATH /var/www/html/arjun_p_s/student-management/resources/views/admin/layouts/left-menu.blade.php ENDPATH**/ ?>