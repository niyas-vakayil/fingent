<!doctype html>
<html lang="en">
<head>
    <input type="hidden" value="<?php echo e(url('/')); ?>" id="site-url"/>
    <?php echo $__env->make('admin.layouts.meta-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php echo $__env->yieldPushContent('css'); ?>

</head>

<body class="pt-0">
    <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="dashboard-main" data-current-page="materials">
        <div class="container-fluid">
            <div class="row">
                <div class="left-menu-wrap col">
                    <?php echo $__env->make('admin.layouts.left-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                <!-- BEGIN: Content Dynamically -->
                <?php echo $__env->yieldContent('content'); ?>
                <!-- END: Content -->
                
                <!-- </div> -->
            </div>
            
        </div>
    </main>

    <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php if($message = Session::get('success')): ?>
        <script type="text/javascript">
            toastr.success("<?php echo e($message); ?>", "Success", {
                progressBar: !0
            })
        </script>
    <?php endif; ?>
    <?php if($message = Session::get('error')): ?>
        <script type="text/javascript">
            toastr.error("<?php echo e($message); ?>", "Fail", {
                progressBar: !0
            })
        </script>
    <?php endif; ?>

    <?php echo $__env->yieldPushContent('js'); ?>
</body>
</html><?php /**PATH /var/www/html/arjun_p_s/student-management/resources/views/admin/layouts/app.blade.php ENDPATH**/ ?>