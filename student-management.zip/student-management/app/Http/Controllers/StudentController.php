<?php

namespace App\Http\Controllers;

use App\Http\Requests\StudentValidationRequest;
use App\Models\Student;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Arr;

class StudentController extends Controller
{

    public function __construct(Student $student)
    {
        $this->model =  $student;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $students = Student::get();
        return view('admin.student-list',compact('students'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.student-create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StudentValidationRequest $request)
    {
        try {
            DB::beginTransaction();
            $studentInput = Arr::only($request->all(), $this->model->getFillable());
           
            $result = $this->model->create($studentInput);
            DB::commit();
            if($result){
                return response()->json([
                    'status' => true,
                    'msg' => 'Create astudent successfully',
                ]);
            }
            return response()->json([
                'status' => false,
                'msg'    => 'Something went wrong'
            ], 400);

           
        } catch (Exception $e) {
            logger()->error($e);
            return false;
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        // 
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $student = Student::find($id);
        return view('admin.student-edit',compact('student'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(StudentValidationRequest $request, $id)
    {
        try {
        $result = $this->model->where('id',$id)->update($request->all());
        if($result){
            return response()->json([
                'status' => true,
                'msg' => 'Update astudent successfully',
            ]);
        }
        return response()->json([
            'status' => false,
            'msg'    => 'Something went wrong'
        ], 400);

       
        } catch (Exception $e) {
            logger()->error($e);
            return false;
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $result = $this->model->delete($id);
        return Redirect::back()->with('message','Operation Successful !');
    }
}
