<?php

namespace App\Http\Controllers;

use App\Http\Requests\MarkValidationRequest;
use App\Models\Mark;
use App\Models\Student;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Arr;


class MarkListController extends Controller
{
    public function __construct(Mark $mark)
    {
        $this->model =  $mark;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $marks = $this->model->get();
        return view('admin.mark-list',compact('marks'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $studentList = Student::select('id','name')->get();
        return view('admin.mark-create',compact('studentList'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(MarkValidationRequest $request)
    {
        try {
            $data = $request->all();
            $data['total_marks'] = $data['maths']+$data['science']+$data['history'];
            DB::beginTransaction();
            $markInput = Arr::only($data, $this->model->getFillable());
            $result = $this->model->create($markInput);
            DB::commit();
            if($result){
                return response()->json([
                    'status' => true,
                    'msg' => 'Mark created successfully',
                ]);
            }
            return response()->json([
                'status' => false,
                'msg'    => 'Something went wrong'
            ], 400);

           
        } catch (Exception $e) {
            logger()->error($e);
            return false;
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $studentList = Student::select('id','name')->get();
        $mark = $this->model->find($id);
        return view('admin.mark-edit',compact('studentList','mark'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        try {
            $result = $this->model->where('id',$id)->update($request->all());
            if($result){
                return response()->json([
                    'status' => true,
                    'msg' => 'Update astudent successfully',
                ]);
            }
            return response()->json([
                'status' => false,
                'msg'    => 'Something went wrong'
            ], 400);
    
           
            } catch (Exception $e) {
                logger()->error($e);
                return false;
            }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $result = $this->model->delete($id);
        return Redirect::back()->with('message','Operation Successful !');
    }
}
