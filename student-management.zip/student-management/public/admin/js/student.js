'use strict';
var Student = {};

(function (Student) {
    
    Student.elements = {
        siteUrl : '#site-url',
        formAddStudent: '#js-student-submit-form',
        formUpdateStudent: '#js-student-update-form',
        btnStudentUpdate : '#student-update-btn',
        btnStudentAdd : '#student-add-btn',

    }

    Student.cache = {
        baseUrl : '',
        customerArray : [],
    }


    Student.init = () => {
        Student.bindControls();
    }

    Student.bindControls = () => {
        
        Student.cache.baseUrl = $(Student.elements.siteUrl).val();
        
        $(Student.elements.btnStudentAdd).on('click', function (e) {
            e.preventDefault();
            if (!$(this).hasClass('disabled')) {
                 console.log('niyas');
                $(Student.elements.formAddStudent).submit();
            }
        })

       


        $(Student.elements.formAddStudent).validate({
            rules: {
                name:{
                    required: true,
                },
                age:{
                    required: true,
                },
                gender:{
                    required: true,
                },
                reporting_teacher:{
                    required: true,
                },
              
            },
             errorPlacement: function (error, element) {
                var name = $(element).attr('name');
                $('#js_' + name + '_error').html(error);
                $('.js_' + name + '_error').html(error);
            },
            submitHandler: function (form) {
                console.log('mnv');
                var formData =new FormData($(Student.elements.formAddStudent)[0]);
                console.log(formData);
                $.ajax({
                    type: "POST",
                    url: Student.cache.baseUrl+'/students',
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false,
                    dataType: 'JSON',
                    beforeSend: function () {
                        $(Student.elements.btnStudentAdd).text('Please wait..');
                    },
                    success: function (res) {
                        toastr.success('Ceate a student Successfully.');  
                        $(Student.elements.btnStudentAdd).text('Submit');
                    },
                    error: function (error) {
                        console.log(error);
                        toastr.error(error);
                        $(Student.elements.btnStudentAdd).text('Submit');

                    },
                });
            },
          
        });


        $(Student.elements.btnStudentUpdate).on('click', function (e) {
            e.preventDefault();
            if (!$(this).hasClass('disabled')) {
                console.log('niyas');
                $(Student.elements.formUpdateStudent).submit();
            }
        })

        $(Student.elements.formUpdateStudent).validate({
            rules: {
                name:{
                    required: true,
                },
                age:{
                    required: true,
                },
                gender:{
                    required: true,
                },
                reporting_teacher:{
                    required: true,
                },
              
            },
             errorPlacement: function (error, element) {
                var name = $(element).attr('name');
                $('#js_' + name + '_error').html(error);
                $('.js_' + name + '_error').html(error);
            },
            submitHandler: function (form) {
                console.log('mnv');
                var studentId = $('#student_id').val();
                var formData =new FormData($(Student.elements.formUpdateStudent)[0]);
                console.log(formData);
                $.ajax({
                    type: "PATCH",
                    url: Student.cache.baseUrl+'/students/'+studentId,
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false,
                    dataType: 'JSON',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    beforeSend: function () {
                        $(Student.elements.btnStudentUpdate).text('Please wait..');
                    },
                    success: function (res) {
                        toastr.success('Update a student Successfully.');  
                        $(Student.elements.btnStudentUpdate).text('Update');
                    },
                    error: function (error) {
                        console.log(error);
                        toastr.error(error);
                        $(Student.elements.btnStudentUpdate).text('Update');

                    },
                });
            },
          
        });


       
    }

   
})(Student)