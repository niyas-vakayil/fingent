'use strict';
var Mark = {};

(function (Mark) {
    
    Mark.elements = {
        siteUrl : '#site-url',
        formAddMark: '#js-mark-submit-form',
        btnMarkAdd : '#mark-add-btn',

    }

    Mark.cache = {
        baseUrl : '',
        customerArray : [],
    }


    Mark.init = () => {
        Mark.bindControls();
    }

    Mark.bindControls = () => {
        
        Mark.cache.baseUrl = $(Mark.elements.siteUrl).val();
        
        $(Mark.elements.btnMarkAdd).on('click', function (e) {
            e.preventDefault();
            if (!$(this).hasClass('disabled')) {
                 console.log('niyas');
                $(Mark.elements.formAddMark).submit();
            }
        })

       


        $(Mark.elements.formAddMark).validate({
            rules: {
                student_id:{
                    required: true,
                },
                maths:{
                    required: true,
                },
                science:{
                    required: true,
                },
                history:{
                    required: true,
                },
                term:{
                    required: true,
                },
              
            },
             errorPlacement: function (error, element) {
                var name = $(element).attr('name');
                $('#js_' + name + '_error').html(error);
                $('.js_' + name + '_error').html(error);
            },
            submitHandler: function (form) {
                console.log('mnv');
                var formData =new FormData($(Mark.elements.formAddMark)[0]);
                console.log(formData);
                $.ajax({
                    type: "POST",
                    url: Mark.cache.baseUrl+'/marks',
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false,
                    dataType: 'JSON',
                    beforeSend: function () {
                        $(Mark.elements.btnMarkAdd).text('Please wait..');
                    },
                    success: function (res) {
                        toastr.success('Ceate a Mark Successfully.');  
                        $(Mark.elements.btnMarkAdd).text('Submit');
                    },
                    error: function (error) {
                        console.log(error);
                        toastr.error(error);
                        $(Mark.elements.btnMarkAdd).text('Submit');

                    },
                });
            },
          
        });



       
    }

   
})(Mark)