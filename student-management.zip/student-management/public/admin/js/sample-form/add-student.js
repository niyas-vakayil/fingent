'use strict';
var AddStudent = {};

(function (AddStudent) {
    
    AddStudent.elements = {
        siteUrl : '#site-url',
        formRegistration : '#js-registration-form',
        formSubmit  : '#js-registration-submit-btn',
        txtPassword : '#js-password',
        checkboxRememberMe : '#js-remember-me',
        btnLoginSubmitBtn : '#js-submit-btn',
    }

    AddStudent.cache = {
        baseUrl : '',
        customerArray : [],
    }


    AddStudent.init = () => {
        AddStudent.bindControls();
    }

    AddStudent.bindControls = () => {
        

        AddStudent.cache.baseUrl = $(AddStudent.elements.siteUrl).val();
        $(document).on('click', AddStudent.elements.formSubmit, function () {
            if (!$(this).hasClass('disabled')) {
    
                $(AddStudent.elements.formRegistration).submit();
            }
        })

        $(AddStudent.elements.formRegistration).validate({
            rules: {
                name: {
                    required: true,
                },
                dob: {
                    required : false,
                    date : true,
                },
                mobile:{
                    required: true,
                    number: true
                },
                email:{
                    required: true,
                },
                password:{
                    required: true,
                },
              
            },
             errorPlacement: function (error, element) {
                var name = $(element).attr('name');
                $('#js_' + name + '_error').html(error);
                $('.js_' + name + '_error').html(error);

            },
            submitHandler: function (form) {
                var formData =new FormData($(AddStudent.elements.formRegistration)[0]);
                $.ajax({
                    type: "POST",
                    url: AddStudent.cache.baseUrl + '/student/add',
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false,
                    dataType: 'JSON',
                    beforeSend: function () {
                        $(AddStudent.elements.formSubmit).text('Please wait..');
                    },
                    success: function (res) {
                        toastr.success('Student added succefully.');
                        $(AddStudent.elements.formSubmit).text('Submit');

                    },
                    error: function (error) {
                        toastr.error('Something went wrong.');
                        $(AddStudent.elements.formSubmit).text('Submit');

                    },
                });
            },
        });


        $(AddStudent.elements.btnLoginSubmitBtn).on('click', function (e) {
            e.preventDefault();
            alert('You clicked Alert Button');
        });


        

    }

    AddStudent.myfunction =  (param) => {
        console.log(param)
        alert('hello');
    }

    AddStudent.mySecondFunction = (param1, param2) => {
        console.log('inside function 2')
    }

})(AddStudent)