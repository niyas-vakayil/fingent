// select current page
$("#" + $("[data-current-page]").attr("data-current-page") + "-link").parents("li").addClass("active"); 
// end select current page






document.body.innerHTML += "<a href='#' id='back-to-top' title=''></a>";
const getBTTElm = document.getElementById('back-to-top');
document.addEventListener('scroll', ev => {
    if (window.scrollY > 150) {
        getBTTElm.classList.add('visible');
    } else {
        getBTTElm.classList.remove('visible');
    }
});
getBTTElm.addEventListener('click', e => {
    e.preventDefault();
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
})






// menu function

const getBtn = document.querySelector('.mob-btn');
if(getBtn != null){
    getBtn.addEventListener('click', e => {
        document.querySelector('body').classList.toggle('show-menu');
    });
}



// const getDropDown = document.getElementsByClassName('main-nav');
// for ( div of getDropDown){
//     var selectLi = div.getElementsByTagName('li');
//     for ( li of selectLi){
//        if (li.contains(li.querySelector('ul'))) {
//         li.classList.add('submenu');
//         li.innerHTML += '<span class="icon-chevron-down"></span>';
//         }
//     }
// }

const getDropDownClick = document.querySelectorAll('.main-nav i');
getDropDownClick.forEach((item) => {
    item.addEventListener('click', e => {
        e.target.parentNode.classList.toggle('open');
    })
})







//animation
// just "anim" in your element
window.addEventListener("load", () => {
    function isInViewport(el, gap) {
        let top = el.offsetTop;
        let left = el.offsetLeft;
        let height = el.offsetHeight;
        console.log(el.offsetParent);
        while (el.offsetParent) {
            el = el.offsetParent;
            top += el.offsetTop;
            left += el.offsetLeft;
        }
        return (
            (window.pageYOffset + window.innerHeight - gap) >= (top) &&
            (window.pageYOffset) <= (height + top)
        );
    }
    let getElem = document.querySelectorAll('.anim');
    //please change as per the design
    const breakPoints = {
        desktop: 250,
        laptop: 80,
        tab: 50,
        mobile: 30
    };
    let targetGap;
    window.innerWidth >= 1200 ? targetGap = breakPoints.desktop :
        window.innerWidth >= 1024 ? targetGap = breakPoints.laptop :
        window.innerWidth >= 768 ? targetGap = breakPoints.tab :
        targetGap = breakPoints.mobile;

    function anim() {
        getElem.forEach(element => {
            isInViewport(element, targetGap) ? element.classList.add("visible") : null;
        })
    }
    getElem.length > 0 ? (window.addEventListener('scroll', anim, false)) : null;
    getElem.length > 0 ? anim() : null;
}, false);

if($("select.custom-select").length != 0){
    $('select.custom-select').select2();
}
if($("select.custom-select-type2").length != 0){
    $('select.custom-select-type2').select2({
        minimumResultsForSearch: -1,
        theme: 'default custom-select-type2--theme'

    });
}


// chart




var config = {
    type: 'line',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July'],
        datasets: [{
            
           
        }, {
            label: false,
            backgroundColor: "#FFEFEF",
            borderColor: "#FF8181",
            pointBackgroundColor:  "#FF8181",
            fill: true,
            lineTension: 0,
            data: [
                4,
                3.8,
                4,
                4.5,
                4.5,
                5,
                4.5
            ],
    
        }]
    },
    options: {
        responsive: true,
        title: {
            display: false,
            text: 'Chart.js Line Chart - Logarithmic'
        },
        scales: {
            xAxes: [{
                gridLines: {
                    drawOnChartArea: false
                }
        
            }],
            yAxes: [{
                gridLines: {
                    drawOnChartArea: false
                }
            }]
        },
        legend: {
            display: false
        }
    }
};
if($("#canvas").length != 0){
    window.onload = function() {
        var ctx = document.getElementById('canvas').getContext('2d');
        window.myLine = new Chart(ctx, config);
    };
}

// var gradientFill = ctx.createLinearGradient(500, 0, 100, 0);
// gradientFill.addColorStop(0, "rgba(128, 182, 244, 0.6)");
// gradientFill.addColorStop(1, "rgba(244, 144, 128, 0.6)");


// document.getElementById('randomizeData').addEventListener('click', function() {
//     config.data.datasets.forEach(function(dataset) {
//         dataset.data = dataset.data.map(function() {
//             return randomScalingFactor();
//         });

//     });

//     window.myLine.update();
// });
// end chart
// signup
$(".show-password").on("click",function(){
    var $this = $(this);
    var thisInput = $this.parents(".input-group").find("input");
    $this.toggleClass("show");
    thisInput.attr("type") == "password" ? thisInput.attr("type","text") : thisInput.attr("type","password"); 
});

function isdInput(inpSelect) {
    let jsinput = document.querySelector(inpSelect);
    if(jsinput != null){
        let iti = window.intlTelInput(jsinput, {
            separateDialCode: true,
            utilsScript: "https://cdn.jsdelivr.net/npm/intl-tel-input@17.0.3/build/js/utils.js",
        });
    }
}
isdInput(".telephone");

function aniendfunction(e){
    e.currentTarget.closest(".telephone-wrap").classList.add("hide-label");
}

$(document).on("webkitAnimationStart",".telephone",function(e){
    aniendfunction(e)
});
$(document).on("animationstart",".telephone",function(e){
    aniendfunction(e)
});
$(document).on("blur mouseout",".telephone:not(:focus)",function(){
    let $this = $(this);
    let inval = $this.val().length;
    if(inval == 0){
        $this.parents(".telephone-wrap").removeClass("hide-label");
    }
});

// $('input[type="tel"]').on("keydown keyup",function(e){
//   if (/\D/g.test(this.value)){
//     this.value = this.value.replace(/\D/g, '');
//   }
// });

$(document).on("input", 'input[type="tel"]', function() {
    this.value = this.value.replace(/\D/g,'');
});

// otp
$('.js-otp-inputs-wrap').find('input').each(function() {
    let otpInput = $('.js-otp-inputs-wrap input');
    let submit = $('button[type="submit"]');
    $(this).attr('maxlength', 1);

    
    $(this).on('keyup', function(e) {
        let parent = $($(this).parent());
        
        if(e.keyCode === 8 || e.keyCode === 37) {
            let prev = $(".js-otp-inputs-wrap input").eq(($(this).index()) - 1);
            if(prev.length && $(this).index() != 0 ) {
                $(prev).select();
            }
        } else if((e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 65 && e.keyCode <= 90) || (e.keyCode >= 96 && e.keyCode <= 105) || e.keyCode === 39) {
            let next = $(".js-otp-inputs-wrap input").eq(($(this).index()) + 1);
            if(next.length) {
                $(next).select();
            } else {
                $('button[type="submit"]').focus();
            }
        }
        let thisInput = $(this);
        if( !$(this).val()){
            thisInput.removeClass("js-input-active");
        }else{
            thisInput.addClass("js-input-active");
        }
        if( otpInput.eq(0).val() && otpInput.eq(1).val() && otpInput.eq(2).val() && otpInput.eq(3).val() && otpInput.eq(4).val()){
            submit.removeClass('ui-disabled'); 
        }else{
            submit.addClass('ui-disabled');
        }
    });
});
// end otp

// left menu
$(".left-menu-list .dropdown").on("click",function(e){
    e.preventDefault();
    if($(this).hasClass("dropdown-active") == false){
        $(".left-menu-list .dropdown.dropdown-active").parents("li").children("ul").slideUp();
        $(".left-menu-list .dropdown.dropdown-active").removeClass("dropdown-active");
        $(this).addClass("dropdown-active").parents("li").children("ul").slideDown();
    }else{
        $(this).removeClass("dropdown-active").parents("li").children("ul").slideUp();
    }
});
// end left menu
// date picker
if($('.date-input').length != 0){
    $('.date-input').datepicker({
        todayHighlight: true,
        // format: 'Y-m-d',Fdat
    });

}
if($('#datepicker').length != 0){
    $('#datepicker').datepicker({
        todayHighlight: true
    });
    $('#datepicker').on('changeDate', function() {
        $('#my_hidden_input').val(
            $('#datepicker').datepicker('getFormattedDate')
        );
    });
}
// date picker
function datatable(id,line){
    if($(id).length != 0){
        $(id).each(function(){
            var $this = $(this);
            $this.DataTable({
                pageLength: line,
                info: false,
                searching: false,
                bLengthChange: true,
                "sDom": 'Rfrtlip',
                responsive: true,
                "oLanguage": {
                    "sLengthMenu": " _MENU_ Per page",
                }

            });


            let myid = $this;
            let trlength = myid.find("tbody tr").length;
            if(trlength <= line - 1){
                myid.parents(".custom-data-table-wrap").addClass("hide-paginate");
            }else{
                myid.parents(".custom-data-table-wrap").removeClass("hide-paginate");
            };

        });
    


        

    }

}
datatable("#example1",4);
datatable("#example3",4);
datatable("#example",4);
datatable("#students-table",10);
// datatable("#message-groups-table",4);
datatable("#active-inactive-table",10);
datatable(".approved-rejected-table",10);
if($('#message-groups-table').length != 0){
    var oTable = $('#message-groups-table').dataTable( {
        "aoColumnDefs": [
            { "bSortable": false, "aTargets": [ 4 ] }, 
            { "bSearchable": false, "aTargets": [ 4 ] }
        ]
    });
}

// $(window).on("load",function(){
//     let myid = $("#students-table");
//     let trlength = myid.find("tr").length;
//     if(trlength <= 10){
//         myid.parents(".custom-data-table-wrap").addClass("hide-paginate");
//     }else{
//         myid.parents(".custom-data-table-wrap").removeClass("hide-paginate");
//     };
// });

$(".languages-known-add").on("click",function(){
    $(".languages-known-append-to-item .languages-known-item").eq(0).clone().appendTo(".languages-known-wrap");
});



$("input.custom-input-file[type='file']").on("change",function(event){
    //alert("hi");
    var fileName = $(this).val();
    $(this).siblings(".file-value").hide();   
    $(this).parent().append("<i class='file-value-name'>"+ event.target.files[0].name +"</i>");
});

$(".increment-btn-add").on("click",function(){
    let $this = $(this);
    let fileClone = $this.parents(".item-increment-input").find(".increment-clone .form-inline").clone();
    fileClone.find("select").addClass("custom-select new-custom-select");
    let appendTofile = $(this).parents(".item-increment-input").find(".increment-wrap");
    fileClone.appendTo(appendTofile);
    $('select.custom-select').not(".select2-hidden-accessible").select2();
});

// textarea resizeable
$("textarea.resizeable").each(function () {
    this.setAttribute("style", "height:" + (this.scrollHeight) + "px;overflow-y:hidden;");
  }).on("input", function () {
    this.style.height = "auto";
    this.style.height = (this.scrollHeight) + "px";
  });
//   radio profit change
$(".radio-profit-wrap input").on("change",function(){
   if($("#radio-for-profit-1:checked").length == 1){
    $(".non-profit-col-wrap").removeClass("show");
    $(".for-profit-col-wrap").addClass("show");
   }else{
    $(".for-profit-col-wrap").removeClass("show");
    $(".non-profit-col-wrap").addClass("show");
   }
       
});
$('.no-sorting').each(function() {
    $(this).removeClass('sorting sorting_desc sorting_asc');
    $(this).unbind('click');
 });

 $("[data-href]").on("click",function(){
    window.location.href = $(this).attr("data-href");
 });


 function loadJS(u) {
    var r = document.getElementsByTagName("script")[0],
        s = document.createElement("script");
        s.src = u;
        r.parentNode.insertBefore(s, r);
    }

    const imglazy = new IntersectionObserver((entries) =>
        entries.forEach((entry) => {
            if (entry.isIntersecting) {
                const image = entry.target;
                image.src = image.dataset.src;
                image.classList.remove("lazyload");
                image.classList.add("lazyloaded");
                imglazy.unobserve(image);
            }
        })
    );
    document.querySelectorAll(".lazyload").forEach((element) => imglazy.observe(element));