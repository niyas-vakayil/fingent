@extends('admin.layouts.app')


@push('css')
    <title>Student Management</title>
     <!-- calender -->
    <link rel="stylesheet" href="{{asset('admin/assets/css/bootstrap-datepicker3.standalone.min.css')}}">
    <link rel="stylesheet" href="{{asset('admin/assets/css/bootstrap-datepicker3.min.css')}}">

    <!-- end calender -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" as="style"> 
    <link rel="stylesheet" href="{{asset('admin/assets/css/pages/add-teacher.css')}}">
@endpush


@section('content')


            <div class="main-dashboard-wrap col py-3">
                <div class="row">
                        <div class="col-md-4">
                            <a class="ttl-12 text-c-text mb-2 d-inline-block" href="live-classes.php"><span class="icon-chevron-left text-icon-gray ttl-9 top-1"></span> Back</a>
                            <div class="radio-tab-heading">
                                <h4 class="ttl-18 my-2">Create New Student</h4>
                            </div>    
                           
                        </div>
                        <div class="col-md-8 text-right">
                            
                        </div>
                    </div>

                    <!--  -->
                    <div class="row dashboard-row mt-2">
                        
                        
                        
                        <!--  -->
                        <div class="col-full">
                            <div class="col-content-wrap col-content-border p-3 h-100 add-live-class-wrap">
                                

                                    <div class="row">
                                        <div class="col-lg-8 account-details-wrap px-4 radio-tabs">
                                            <!-- <form> -->
                                                <div class="form-row">
                                                    <div class="col-md-12"> 
                                                        <div class="org-type d-flex">     
                                                            <div class="form-group custom_radio mr-5">
                                                                <input type="radio" id="radioVideo" name="radio-tab" checked="">
                                                                <label for="radioVideo">Video</label>
                                                            </div>
                                                                                                               
                                                        </div>
                                                    </div>
                                                    <!--  -->



                                                    <div class="radio-tab-content col-md-12 js-video-add-module">
                                                        <div class="form-row">
                                                            <form id="js-student-submit-form">
                                                                @csrf
                                                                <div class="col-md-6">
                                                                    <div class="iilt-group1 form-group w-100">
                                                                        <label class="form-label ttl-14">Name</label>
                                                                        
                                                                        <input class="form-input form-control" type="text" name="name" id="name" placeholder="Enter module title" style="width: 400px;">
                                                                        <span class="error input-notification" id="js_name_error"></span>
                                                                    </div> 
                                                                </div>                                                    
                                                                <!--  -->
                                                                <div class="col-md-6">
                                                                    <div class="iilt-group1 form-group w-100">
                                                                        <label class="form-label ttl-14">Age</label>
                                                                        <input class="form-input form-control" type="text" name="age" id="age" placeholder="Enter module title" style="width: 400px;">
                                                                        <span class="error input-notification" id="js_age_error"></span>
                                                                    </div> 
                                                                </div>     
                                                               
                                                                <div class="col-md-6">
                                                                    <div class="iilt-group1 form-group w-100">
                                                                    <label class="form-label ttl-14">Gender</label>
                                                                    <select class="custom-select form-control" id="gender" name="gender">  
                                                                            <option value="male">male</option>
                                                                            <option value="female">female</option>    
                                                                    </select>
                                                                        <span class="error input-notification" id="js_gender_error"></span>
                                                                    </div> 
                                                                </div>
                                                                <!--  -->

                                                                <div class="col-md-6">
                                                                    <div class="iilt-group1 form-group w-100">
                                                                    <label class="form-label ttl-14">Reporting Teacher</label>
                                                                    <select class="custom-select form-control" id="reporting_teacher" name="reporting_teacher">  
                                                                            <option value="teacher1">Teacher1</option>
                                                                            <option value="teacher2">Teacher2</option>    
                                                                    </select>
                                                                        <span class="error input-notification" id="js_teacher_error"></span>
                                                                    </div> 
                                                                </div>
                                                                
                                                               
                                                                
                                                                
                                                                
                                                                
                                                                <div class="col-md-12 pt-3">
                                                                    <button id="student-add-btn" data-next="sections-lessons" type="button" class="btn btn-primary px-5 reg-next-btn">Submit</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>

                                                    <!-- video Radio Tab content End -->

                                                    
                                                    
                                                </div>
                                            <!-- </form> -->
                                        </div>
                                    </div>









                               
                            

                            </div>
                        </div>

                    </div>
                    <!--  -->
            </div>



            <!-- dummy section -->

            

@endsection

@push('js')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/intl-tel-input@17.0.3/build/js/intlTelInput.js"></script>
    <!-- chart -->
    <!-- <script src="https://cdn2.hubspot.net/hubfs/476360/Chart.js"></script>
    <script src="https://cdn2.hubspot.net/hubfs/476360/utils.js"></script> -->
    <!-- end chart -->
    <!-- calender -->
    <script type="text/javascript" src="{{asset('admin/assets/js/bootstrap-datepicker.min.js')}}"></script>
    <!-- end calender -->
    <script type="text/javascript" src="{{asset('admin/assets/js/main.js')}}"></script>
    <script src="{{ asset('vendor/validator/jquery.validate.min.js') }}"></script>
    <script src="{{ asset('vendor/validator/additional-methods.min.js') }}"></script>

	<script src = "{{asset('admin/js/student.js')}}"> </script>
    
    <script>

    $(document).ready(function () {
        Student.init();
        
    });



    </script>

    <script>
        $("[data-link]").on("click",function(){
            window.location.href = $(this).attr("data-link")
        });

        // $(".reg-next-btn[data-next]").on("click",function(){
        //     //alert("fii");
        //     var nextTab = $(this).attr("data-next");
        //     $(".steps-progress-bar li.active").removeClass("active");
        //     $(".account-add-details.show").removeClass("show");
        //     $("#" + nextTab + "-nav").addClass("active");
        //     $("#" + nextTab + "-tab").addClass("show");
        // });

        $('#addMaterial').select2({
            tags: true,
            placeholder: {
                id: '-1', // the value of the option
                text: 'Add material'
            },
            "language": {
                "noResults": () => "Add material"

            }
        });

        $('#addFollowup').select2({
            tags: true,
            placeholder: {
                id: '-1', // the value of the option
                text: 'Add follow up'
            },
            "language": {
                "noResults": () => "Add follow up"

            }
        });

        $('#addExercise').select2({
            tags: true
        });
        $("input.select2-search__field").attr("placeholder", "Search Exercise");  
        $('#addExercise').on('select2:close', function(e) {
            $('#sections-exercise-tab input.select2-search__field').prop('placeholder', 'Search Exercise');
        });    
        //$('input.select2-search__field', $('#addExercise')).prop('placeholder', 'Search Exercise');


    // Radio Tab-------
        $('[name=radio-tab]').each(function(i,d){
            var radiochecked = $(this).prop('checked');
            var progressradiochecked = $(this).prop('checked');
            //   console.log(p);
            if(radiochecked){
                $('.radio-tab-content').eq(i)
                .addClass('on');
            }  
            if(progressradiochecked){
                $('.radio-tab-steps-progress').eq(i)
                .addClass('on');
            } 
            if(progressradiochecked){
                $('.radio-tab-heading').eq(i)
                .addClass('on');
            }    
        });  

        $('[name=radio-tab]').on('change', function(){
            var radiochecked = $(this).prop('checked');
            //var progressradiochecked = $(this).prop('checked');
            
            // $(type).index(this) == nth-of-type
            var i = $('[name=radio-tab]').index(this);
            
            $('.radio-tab-content').removeClass('on');
            $('.radio-tab-content').eq(i).addClass('on');

            $('.radio-tab-steps-progress').removeClass('on');
            $('.radio-tab-steps-progress').eq(i).addClass('on');

            $('.radio-tab-heading').removeClass('on');
            $('.radio-tab-heading').eq(i).addClass('on');
        });


         // Input Text Remove-----------

        $(".removeurl").click(function(e) {
            e.preventDefault();
            $(this).parent().find(".form-control").val('');
            $(this).hide();
        });      


        $('.input-clear').on('keyup change', function() {
            if ($.trim(this.value).length > 0) $(this).parent().find('.removeurl').css({"display": "flex"})
            else $(this).parent().find('.removeurl').hide()
        });
        



    // File Uploder-----------

    $.fn.fileUploader = function (filesToUpload, sectionIdentifier) {
        var fileIdCounter = 0;

    this.closest(".files-wrap").change(function (evt) {       
        //$(this).closest("ul").css({"display": "none", "border": "2px solid red"}); 
        
        //$(this).parent().find(".file-value").hide();
        $(this).parent().find(".files-wrap") .removeClass("file-removed");
        $(this).parent().find(".files-wrap") .addClass("file-changed");
        //alert("change");
        
        var output = [];

        for (var i = 0; i < evt.target.files.length; i++) {
            //fileIdCounter++;
            var file = evt.target.files[i];
            var fileId = sectionIdentifier + fileIdCounter;

            filesToUpload.push({
                id: fileId,
                file: file
            });

            var removeLink = "<a class=\"removeFile\" href=\"#\" data-fileid=\"" + fileId + "\"><span class='icon-close'></span></a>";

            output.push("<li>", escape(file.name), "</strong>  ", removeLink, "</li> ");
        };

        $(this).children(".files-list")
            .append(output.join(""));

        //reset the input to null - nice little chrome bug!
        evt.target.value = null;
    });

    $(this).on("click", ".removeFile", function (e) {

        $(this).closest(".files-wrap") .addClass("file-removed");
        $(this).closest(".files-wrap") .removeClass("file-changed");


        $(this).closest(".files-wrap") .find(".file-value") .css({"display": "block"});

        e.preventDefault();

        var fileId = $(this).parent().children("a").data("fileid");

        // loop through the files array and check if the name of that file matches FileName
        // and get the index of the match
        for (var i = 0; i < filesToUpload.length; ++i) {
            if (filesToUpload[i].id === fileId)
                filesToUpload.splice(i, 1);
        }

       //$(this).parent().remove();
       $(this).closest("ul").empty();

        
    });

    this.clear = function () {
        for (var i = 0; i < filesToUpload.length; ++i) {
            if (filesToUpload[i].id.indexOf(sectionIdentifier) >= 0)
                filesToUpload.splice(i, 1);
        }

        $(this).children(".files-list").empty();
    }

    return this;
};

(function () {
    var filesToUpload = [];

    var files1Uploader = $("#files1-upload").fileUploader(filesToUpload, "files1");
    var files2Uploader = $("#files2-upload").fileUploader(filesToUpload, "files2");
    var files3Uploader = $("#files3-upload").fileUploader(filesToUpload, "files3");
    var files4Uploader = $("#files4-upload").fileUploader(filesToUpload, "files4");
    var files5Uploader = $("#files5-upload").fileUploader(filesToUpload, "files5");
    var files6Uploader = $("#files6-upload").fileUploader(filesToUpload, "files6");
    var files7Uploader = $("#files7-upload").fileUploader(filesToUpload, "files7");
    var files8Uploader = $("#files8-upload").fileUploader(filesToUpload, "files8");
    var files9Uploader = $("#files9-upload").fileUploader(filesToUpload, "files8");

    var filesvideo1Uploader = $("#filesvideo1-upload").fileUploader(filesToUpload, "filesvideo1");

    


})()
    </script>




	
@endpush