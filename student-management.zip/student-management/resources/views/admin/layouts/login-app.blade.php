<!doctype html>
<html lang="en">
<head>
    <input type="hidden" value="{{url('/')}}" id="site-url"/>
    @include('admin.layouts.meta-header')


    @stack('css')

</head>

<body class="pt-0">
    <main>
        
                <!-- BEGIN: Content Dynamically -->
                @yield('content')
                <!-- END: Content -->

    </main>

    @include('admin.layouts.footer')
    
    @if($message = Session::get('success'))
        <script type="text/javascript">
            toastr.success("{{ $message }}", "Success", {
                progressBar: !0
            })
        </script>
    @endif
    @if($message = Session::get('error'))
        <script type="text/javascript">
            toastr.error("{{ $message }}", "Fail", {
                progressBar: !0
            })
        </script>
    @endif

    @stack('js')
</body>
</html>