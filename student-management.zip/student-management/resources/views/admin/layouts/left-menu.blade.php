<div class="left-menu-inner">
<ul class="left-menu-list">
    <li>
        <a id="H-link" href="{{route('students.index')}}">
            <span class="icon-Home"></span>Student
        </a>
    </li>
    <li>
        <a id="registration-link" href="{{route('marks.index')}}">
            <span class="icon-Home"></span>Marks
        </a>
    </li>
 
   
  
   
</ul>
</div>