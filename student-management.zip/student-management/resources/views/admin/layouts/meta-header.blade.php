<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0,user-scalable=0"/>
<meta name="theme-color" content="#19AFFF">
<meta name="csrf-token" content="{{ csrf_token() }}">

<!-- Favicons -->
<link rel="apple-touch-icon" href="{{asset('admin/assets/images/favicons/favicon-192-192.png')}}" sizes="192x192">
<link rel="icon" href="{{asset('admin/assets/images/favicons/favicon-57-57.png')}}" sizes="57x57" type="image/png">
<link rel="icon" href="{{asset('admin/assets/images/favicons/favicon-72-72.png')}}" sizes="72x72" type="image/png">
<link rel="icon" href="{{asset('admin/assets/images/favicons/favicon-114-114.png')}}" sizes="114x114" type="image/png">
<link rel="icon" href="{{asset('admin/assets/images/favicons/favicon-144-144.png')}}" sizes="144x144" type="image/png">
<link rel="icon" href="{{asset('admin/assets/images/favicons/favicon-512-512.png')}}" sizes="512x512" type="image/png">
<link rel="icon" href="{{asset('admin/assets/images/favicons/favicon-1024-1024.png')}}" sizes="1024x1024" type="image/png">
<link rel="stylesheet" href="{{ asset('admin/assets/css/main.min.css')}}">
<!-- <link rel="stylesheet" href="{{asset('admin/assets/css/main.min.css')}}"> -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.13/css/intlTelInput.css">

    <noscript>
        <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@xz/fonts@1/serve/hk-grotesk.min.css"> -->
    </noscript>
    <!-- font -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<link rel="manifest" href="../manifest.json">
<link href="{{ asset('vendor/toaster/css/toastr.css') }}" rel="stylesheet" />
