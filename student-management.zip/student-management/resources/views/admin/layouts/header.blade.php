
  <header class="main-header">
        <div class="container-fluid h-100 d-flx flx-vcenter">
            <div class="logo">
                <a href="">
                    <img src="{{asset('admin/assets/images/layout/logo.svg')}}" alt="" srcset="">
                </a>
            </div>
            <div class="header-right ml-auto d-flx flx-vcenter">
                <nav class="main-nav">
                    <ul class="nav-link-list">
                        <li>
                            <div class="iilt-group2 input-group w-100 flex-sm-row-reverse border-round search-input-wrap">
                                <input type="text" class="form-control search-input" id="" placeholder="Search">
                                <div class="input-group-append cursor-pointer">
                                    <div class="input-group-text"><span class="icon-search"></span></div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <a href="" class="d-flex align-items-center notifications-link active">
                                <button class="circle-btn"><span class="icon-notifications ttl-18"></span></button>
                            </a>
                            <ul class="notifications-list">
                                <li class="notification-header">
                                    <h5 class="ttl-14">Notifications <span class="noti-status">4</span></h5>
                                </li>
                                <li class="notifications-wrap">
                                    <ol>
                                        <!--  -->
                                        <li>
                                            <a class="d-flex usr-noti-link" href="">
                                                <div class="usr-dp-wrap">
                                                    <figure class="user-dp md img-center user-image mb-0 mr-2">
                                                        <img class="img-responsive rounded-circle lazyload" data-src="{{asset('admin/assets/images/style-guide/user-1.jpg')}}" alt="" src="">
                                                    </figure>
                                                    <div class="notification-type bg-sky-blue">
                                                        <span class="icon-pen-alt"></span>
                                                    </div>
                                                </div>
                                                <div class="usr-noti-details">
                                                    <p class="this-noti-title"><strong>Jeni Lorence</strong> Submitted Exercise</p>
                                                    <p class="this-noti-time">10 hours ago</p>
                                                </div>
                                            </a>
                                        </li>
                                        <!--  -->
                                        <li>
                                            <a class="d-flex usr-noti-link" href="">
                                                <div class="usr-dp-wrap">
                                                    <figure class="user-dp md img-center user-image mb-0 mr-2 text-c-green bg-light-green">
                                                        <span>C</span>
                                                    </figure>
                                                    <div class="notification-type bg-peach">
                                                        <span class="icon-video"></span>
                                                    </div>
                                                </div>
                                                <div class="usr-noti-details">
                                                    <p class="this-noti-title"><strong>Elizabeth Andrew</strong> Requested OET</p>
                                                    <p class="this-noti-title">Reading slot</p>
                                                    <p class="this-noti-time">10 hours ago</p>
                                                </div>
                                            </a>
                                        </li><li>
                                            <a class="d-flex usr-noti-link" href="">
                                                <div class="usr-dp-wrap">
                                                    <figure class="user-dp md img-center user-image mb-0 mr-2">
                                                        <img class="img-responsive rounded-circle lazyload" data-src="{{asset('admin/assets/images/style-guide/user-1.jpg')}}" alt="" src="">
                                                    </figure>
                                                    <div class="notification-type bg-sky-blue">
                                                        <span class="icon-pen-alt"></span>
                                                    </div>
                                                </div>
                                                <div class="usr-noti-details">
                                                    <p class="this-noti-title"><strong>Jeni Lorence</strong> Submitted Exercise</p>
                                                    <p class="this-noti-time">10 hours ago</p>
                                                </div>
                                            </a>
                                        </li>
                                        <!--  -->
                                        <li>
                                            <a class="d-flex usr-noti-link" href="">
                                                <div class="usr-dp-wrap">
                                                    <figure class="user-dp md img-center user-image mb-0 mr-2 text-c-green bg-light-green">
                                                        <span>C</span>
                                                    </figure>
                                                    <div class="notification-type bg-peach">
                                                        <span class="icon-video"></span>
                                                    </div>
                                                </div>
                                                <div class="usr-noti-details">
                                                    <p class="this-noti-title"><strong>Elizabeth Andrew</strong> Requested OET</p>
                                                    <p class="this-noti-title">Reading slot</p>
                                                    <p class="this-noti-time">10 hours ago</p>
                                                </div>
                                            </a>
                                        </li><li>
                                            <a class="d-flex usr-noti-link" href="">
                                                <div class="usr-dp-wrap">
                                                    <figure class="user-dp md img-center user-image mb-0 mr-2">
                                                        <img class="img-responsive rounded-circle lazyload" data-src="{{asset('admin/assets/images/style-guide/user-1.jpg')}}" alt="" src="">
                                                    </figure>
                                                    <div class="notification-type bg-sky-blue">
                                                        <span class="icon-pen-alt"></span>
                                                    </div>
                                                </div>
                                                <div class="usr-noti-details">
                                                    <p class="this-noti-title"><strong>Jeni Lorence</strong> Submitted Exercise</p>
                                                    <p class="this-noti-time">10 hours ago</p>
                                                </div>
                                            </a>
                                        </li>
                                        <!--  -->
                                        <li>
                                            <a class="d-flex usr-noti-link" href="">
                                                <div class="usr-dp-wrap">
                                                    <figure class="user-dp md img-center user-image mb-0 mr-2 text-c-green bg-light-green">
                                                        <span>C</span>
                                                    </figure>
                                                    <div class="notification-type bg-peach">
                                                        <span class="icon-video"></span>
                                                    </div>
                                                </div>
                                                <div class="usr-noti-details">
                                                    <p class="this-noti-title"><strong>Elizabeth Andrew</strong> Requested OET</p>
                                                    <p class="this-noti-title">Reading slot</p>
                                                    <p class="this-noti-time">10 hours ago</p>
                                                </div>
                                            </a>
                                        </li><li>
                                            <a class="d-flex usr-noti-link" href="">
                                                <div class="usr-dp-wrap">
                                                    <figure class="user-dp md img-center user-image mb-0 mr-2">
                                                        <img class="img-responsive rounded-circle lazyload" data-src="{{asset('admin/assets/images/style-guide/user-1.jpg')}}" alt="" src="">
                                                    </figure>
                                                    <div class="notification-type bg-sky-blue">
                                                        <span class="icon-pen-alt"></span>
                                                    </div>
                                                </div>
                                                <div class="usr-noti-details">
                                                    <p class="this-noti-title"><strong>Jeni Lorence</strong> Submitted Exercise</p>
                                                    <p class="this-noti-time">10 hours ago</p>
                                                </div>
                                            </a>
                                        </li>
                                        <!--  -->
                                        <li>
                                            <a class="d-flex usr-noti-link" href="">
                                                <div class="usr-dp-wrap">
                                                    <figure class="user-dp md img-center user-image mb-0 mr-2 text-c-green bg-light-green">
                                                        <span>C</span>
                                                    </figure>
                                                    <div class="notification-type bg-peach">
                                                        <span class="icon-video"></span>
                                                    </div>
                                                </div>
                                                <div class="usr-noti-details">
                                                    <p class="this-noti-title"><strong>Elizabeth Andrew</strong> Requested OET</p>
                                                    <p class="this-noti-title">Reading slot</p>
                                                    <p class="this-noti-time">10 hours ago</p>
                                                </div>
                                            </a>
                                        </li><li>
                                            <a class="d-flex usr-noti-link" href="">
                                                <div class="usr-dp-wrap">
                                                    <figure class="user-dp md img-center user-image mb-0 mr-2">
                                                        <img class="img-responsive rounded-circle lazyload" data-src="{{asset('admin/assets/images/style-guide/user-1.jpg')}}" alt="" src="">
                                                    </figure>
                                                    <div class="notification-type bg-sky-blue">
                                                        <span class="icon-pen-alt"></span>
                                                    </div>
                                                </div>
                                                <div class="usr-noti-details">
                                                    <p class="this-noti-title"><strong>Jeni Lorence</strong> Submitted Exercise</p>
                                                    <p class="this-noti-time">10 hours ago</p>
                                                </div>
                                            </a>
                                        </li>
                                        <!--  -->
                                        <li>
                                            <a class="d-flex usr-noti-link" href="">
                                                <div class="usr-dp-wrap">
                                                    <figure class="user-dp md img-center user-image mb-0 mr-2 text-c-green bg-light-green">
                                                        <span>C</span>
                                                    </figure>
                                                    <div class="notification-type bg-peach">
                                                        <span class="icon-video"></span>
                                                    </div>
                                                </div>
                                                <div class="usr-noti-details">
                                                    <p class="this-noti-title"><strong>Elizabeth Andrew</strong> Requested OET</p>
                                                    <p class="this-noti-title">Reading slot</p>
                                                    <p class="this-noti-time">10 hours ago</p>
                                                </div>
                                            </a>
                                        </li><li>
                                            <a class="d-flex usr-noti-link" href="">
                                                <div class="usr-dp-wrap">
                                                    <figure class="user-dp md img-center user-image mb-0 mr-2">
                                                        <img class="img-responsive rounded-circle lazyload" data-src="{{asset('admin/assets/images/style-guide/user-1.jpg')}}" alt="" src="">
                                                    </figure>
                                                    <div class="notification-type bg-sky-blue">
                                                        <span class="icon-pen-alt"></span>
                                                    </div>
                                                </div>
                                                <div class="usr-noti-details">
                                                    <p class="this-noti-title"><strong>Jeni Lorence</strong> Submitted Exercise</p>
                                                    <p class="this-noti-time">10 hours ago</p>
                                                </div>
                                            </a>
                                        </li>
                                        <!--  -->
                                        <li>
                                            <a class="d-flex usr-noti-link" href="">
                                                <div class="usr-dp-wrap">
                                                    <figure class="user-dp md img-center user-image mb-0 mr-2 text-c-green bg-light-green">
                                                        <span>C</span>
                                                    </figure>
                                                    <div class="notification-type bg-peach">
                                                        <span class="icon-video"></span>
                                                    </div>
                                                </div>
                                                <div class="usr-noti-details">
                                                    <p class="this-noti-title"><strong>Elizabeth Andrew</strong> Requested OET</p>
                                                    <p class="this-noti-title">Reading slot</p>
                                                    <p class="this-noti-time">10 hours ago</p>
                                                </div>
                                            </a>
                                        </li><li>
                                            <a class="d-flex usr-noti-link" href="">
                                                <div class="usr-dp-wrap">
                                                    <figure class="user-dp md img-center user-image mb-0 mr-2">
                                                        <img class="img-responsive rounded-circle lazyload" data-src="{{asset('admin/assets/images/style-guide/user-1.jpg')}}" alt="" src="">
                                                    </figure>
                                                    <div class="notification-type bg-sky-blue">
                                                        <span class="icon-pen-alt"></span>
                                                    </div>
                                                </div>
                                                <div class="usr-noti-details">
                                                    <p class="this-noti-title"><strong>Jeni Lorence</strong> Submitted Exercise</p>
                                                    <p class="this-noti-time">10 hours ago</p>
                                                </div>
                                            </a>
                                        </li>
                                        <!--  -->
                                        <li>
                                            <a class="d-flex usr-noti-link" href="">
                                                <div class="usr-dp-wrap">
                                                    <figure class="user-dp md img-center user-image mb-0 mr-2 text-c-green bg-light-green">
                                                        <span>C</span>
                                                    </figure>
                                                    <div class="notification-type bg-peach">
                                                        <span class="icon-video"></span>
                                                    </div>
                                                </div>
                                                <div class="usr-noti-details">
                                                    <p class="this-noti-title"><strong>Elizabeth Andrew</strong> Requested OET</p>
                                                    <p class="this-noti-title">Reading slot</p>
                                                    <p class="this-noti-time">10 hours ago</p>
                                                </div>
                                            </a>
                                        </li>
                                        <!--  -->
                                    </ol>
                                </li>
                                <li class="text-center notification-see-all">
                                    <a href="#">See all</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a class="d-flex align-items-center">
                                <figure class="user-dp sm img-center user-image mb-0 mr-2">
                                    <img class="img-responsive rounded-circle lazyload" data-src="{{asset('admin/assets/images/style-guide/user-1.jpg')}}" alt="" src="">
                                </figure>
                                <span class="icon-chevron-down"></span>
                            </a>
                            <ul class="profile-dropdown">
                                <li>
                                    <a class="d-flex align-items-center profile-link" href="#">
                                        <div>
                                            <figure class="user-dp lg2 img-center user-image mb-0 mr-2">
                                                <img class="img-responsive rounded-circle lazyload" data-src="{{asset('admin/assets/images/style-guide/user-1.jpg')}}" alt="" src="">
                                            </figure>
                                        </div>
                                        <div class="profile-user-details">
                                            <p class="mb-1">Andria</p>
                                            <p class="text-c-gray mb-0 ttl-12">andria@gmail.com</p>
                                        </div>
                                    </a>
                                </li>
                                <li class="divider"></li>
                                <li><a href="profile.php">My Profile</a></li>
                                <li><a href="">Change Password</a></li>
                                <li><a href="">Verification</a></li>
                                <li class="divider"></li>
                                <li><a href=">Logout</a></li>
                            </ul>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
        <div class="mob-btn">
			<span></span>
			<span></span>
			<span></span>
	    </div>
	    <div class="overlay"></div>	
    </header>   
   