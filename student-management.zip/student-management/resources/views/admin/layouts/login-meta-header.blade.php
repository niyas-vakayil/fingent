<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0,user-scalable=0"/>
<meta name="theme-color" content="#19AFFF">
<!-- Favicons -->
<link rel="apple-touch-icon" href="assets/images/favicons/favicon-192-192.png" sizes="192x192">
<link rel="icon" href="assets/images/favicons/favicon-57-57.png" sizes="57x57" type="image/png">
<link rel="icon" href="assets/images/favicons/favicon-72-72.png" sizes="72x72" type="image/png">
<link rel="icon" href="assets/images/favicons/favicon-114-114.png" sizes="114x114" type="image/png">
<link rel="icon" href="assets/images/favicons/favicon-144-144.png" sizes="144x144" type="image/png">
<link rel="icon" href="assets/images/favicons/favicon-512-512.png" sizes="512x512" type="image/png">
<link rel="icon" href="assets/images/favicons/favicon-1024-1024.png" sizes="1024x1024" type="image/png">
<link rel="stylesheet" href="assets/css/main.min.css?v2">

<!-- <link rel="preload" href="assets/font/iconmoon/syneicons.woff?po8cd6" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="assets/font/iconmoon/syneicons.ttf?po8cd6" as="font" type="font/woff2" crossorigin> -->
<!-- <link rel="preload" href="assets/font/iconmoon/syneicons.svg?po8cd6#syneicons" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="assets/font/fontello/deafult-icons.woff?92060687" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="assets/font/fontello/deafult-icons.ttf?92060687" as="font" type="font/woff2" crossorigin> -->
<!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@xz/fonts@1/serve/hk-grotesk.min.css" as="style"> 
<link rel="preload" href="https://cdn.jsdelivr.net/npm/@xz/fonts@1/serve/hk-grotesk.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'"> -->


     
    <noscript>
        <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@xz/fonts@1/serve/hk-grotesk.min.css"> -->
    </noscript>
    <!-- font -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<link rel="manifest" href="../manifest.json">
	<title>IILT</title>
    <!-- date picker -->
    <link rel="stylesheet" href="assets/css/bootstrap-datepicker3.standalone.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap-datepicker3.min.css">
    <!-- select2 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" as="style"> 
    <!-- datatables -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css" as="style">  
    